import pydotplus.graphviz as pydot

class brnode(object):
    """docstring for brnode"""
    def __init__(self, key=None, color=None, left=None, right=None, parent=None):
       self.color   = color
       self.key     = key
       self.left    = left
       self.right   = right
       self.parent  = parent

    def map_color(self):
        if self.color == "red":
            return "red"
        else:
            return "blue"


class brtree(object):

    nil = brnode("nil", "black", None, None, None)

    """docstring for brtree"""
    def __init__(self):
        self.root = self.nil

    """    
    ------------------ Rotate -------------------
    """
    def left_rotate(self, x):
        if x == self.nil or x.right == self.nil:
            return

        y = x.right
        x.right = y.left
        if y.left != self.nil:
            y.left.parent = x

        y.parent = x.parent
        if x.parent == self.nil:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y

        y.left = x
        x.parent = y


    def right_rotate(self, x):
        if x == self.nil or x.left == self.nil:
            return
        y = x.left

        x.left = y.right
        if y.right != self.nil:
            y.right.parent = x

        y.parent = x.parent
        if x.parent == self.nil:
            self.root = y
        elif x.parent.left == x:
            x.parent.left = y
        else:
            x.parent.right = y

        y.right = x
        x.parent = y


    """    
    ------------------ Insert -------------------
    """
    def insert(self, inserted_node):
        y = self.nil
        x = self.root
        while x != self.nil:
            y = x
            if inserted_node.key < x.key:
                x = x.left
            else:
                x = x.right

        inserted_node.parent = y

        if y == self.nil:
            self.root = inserted_node
        elif inserted_node.key < y.key:
            y.left = inserted_node
        else:
            y.right = inserted_node
        
        inserted_node.left  = self.nil
        inserted_node.right = self.nil
        inserted_node.color = "red"
        self.insert_fixup(inserted_node)


    def insert_fixup(self, z):
        while z.parent.color == "red":
            # if z's parent is the left child of z's grandparent
            if z.parent == z.parent.parent.left:
                uncle = z.parent.parent.right

                # case 1
                if uncle.color == "red":
                    z.parent.color = "black"
                    uncle.color = "black"
                    z.parent.parent.color = "red"
                    z = z.parent.parent

                # case 2: convert to case 3
                else:
                    if z == z.parent.right:
                        z = z.parent
                        self.left_rotate(z)

                    # case 3
                    z.parent.color = "black"
                    z.parent.parent.color = "red"
                    self.right_rotate(z.parent.parent)

            # if z's parent is the right child of z's grandparent
            else:
                uncle = z.parent.parent.left

                # case 1
                if uncle.color == "red":
                    z.parent.color = "black"
                    uncle.color = "black"
                    z.parent.parent.color = "red"
                    z = z.parent.parent

                # case 2 or 3
                else:
                    # case 2: convert to case 3
                    if z == z.parent.left:
                        z = z.parent
                        self.right_rotate(z)

                    # case 3
                    z.parent.color = "black"
                    z.parent.parent.color = "red"
                    self.left_rotate(z.parent.parent)

        self.root.color = "black"


    """
    ------------------------ Delete -------------------------
    """

    def delete(self, z):
        y = z
        y_original_color = y.color
        if z.left == self.nil:
            x = z.right
            self.transplant(z, z.right)
        elif z.right == self.nil:
            x = z.left
            self.transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            y_original_color = y.color
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self.transplant(y, y.right)
                y.right = z.right
                y.right.parent = y
            self.transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color

        if y_original_color == "black":
            self.delete_fixup(x)


    def delete_fixup(self, x):
        while x != self.root and x.color == "black":
            if x == x.parent.left:
                w = x.parent.right

                # case 1: convert into case 2
                if w.color == "red":
                    w.color = "black"
                    x.parent.color = "red"
                    self.left_rotate(x.parent)
                    w = x.parent.right

                # case 2
                if w.left.color == "black" and w.right.color == "black":
                    w.color = "red"
                    x = x.parent
                    continue

                # case 3: convert into case 4
                elif w.right.color == "black":
                    w.left.color = "black"
                    w.color = "red"
                    self.right_rotate(w)
                    w = x.parent.right

                # case 4
                w.color = x.parent.color
                x.parent.color = "black"
                w.right.color = "black"
                self.left_rotate(x.parent)
                x = self.root

            else:
                w = x.parent.left

                # case 1: convert into case 2
                if w.color == "red":
                    w.color = "black"
                    x.parent.color = "red"
                    self.right_rotate(x.parent)
                    w = x.parent.left

                # case 2
                if w.right.color == "black" and w.left.color == "black":
                    w.color = "red"
                    x = x.parent
                    continue

                # case 3: convert to case 4
                elif w.left.color == "black":
                    w.right.color = "black"
                    w.color = "red"
                    self.left_rotate(w)
                    w = x.parent.left

                # case 4
                w.color = x.parent.color
                x.parent.color = "black"
                w.left.color = "black"
                self.right_rotate(x.parent)
                x = self.root

        x.color = "black"


    # get the successor of x
    def minimum(self, x):
        while x.left != self.nil:
            x = x.left
        return x


    def transplant(self, u, v):
        if u.parent == self.nil:
            self.root = v
        elif u == u.parent.left:
            u.parent.left = v
        else:
            u.parent.right = v
        v.parent = u.parent


    def search(self, key):
        x = self.root
        while x != self.nil and x.key != key:
            if key < x.key:
                x = x.left
            else:
                x = x.right
        return x


    # return the list of inorder traversal
    def inorder(self, x):
        if x == self.nil:
            return []
        else:
            return self.inorder(x.left) + [x.key] + self.inorder(x.right)


    """
    -------------------- Tree Visualization ------------------
    """
    def generate_node(self, node):
        text = 'key ' + str(node.key)
        return pydot.Node(text, style="filled",fontcolor='ivory', fillcolor=node.color)


    def draw(self, image_name):
        graph = pydot.Dot(graph_type='graph')
        queue = []
        root_node = self.generate_node(self.root)
        queue.append([self.root, root_node])
        graph.add_node(root_node)
        while len(queue) > 0:
            x = queue[0][0].left
            y = queue[0][0].right
            x_node = self.generate_node(x)
            y_node = self.generate_node(y)
            if x != self.nil:
                graph.add_node(x_node)
                graph.add_edge(pydot.Edge(queue[0][1], x_node))
                queue.append([x, x_node])
            if y != self.nil:
                graph.add_node(y_node)
                graph.add_edge(pydot.Edge(queue[0][1], y_node))
                queue.append([y, y_node])
            queue.pop(0)

        graph.write_png(image_name)
            


""""""""""""""" Order Statistics RBTree """""""""""""""


class ostree(brtree):
    """docstring for os_tree"""
    def __init__(self):
        self.root = self.nil
        self.nil.size = 0
        

    def left_rotate(self, x):
        if x == self.nil or x.right == self.nil:
            return
        y = x.right

        x.right = y.left
        if y.left != self.nil:
            y.left.parent = x

        y.parent = x.parent
        if x.parent == self.nil:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y

        y.left = x
        x.parent = y

        y.size = x.size
        x.size = x.left.size + x.right.size + 1


    def right_rotate(self, x):
        if x == self.nil or x.left == self.nil:
            return
        y = x.left

        x.left = y.right
        if y.right != self.nil:
            y.right.parent = x

        y.parent = x.parent
        if x.parent == self.nil:
            self.root = y
        elif x.parent.left == x:
            x.parent.left = y
        else:
            x.parent.right = y

        y.right = x
        x.parent = y

        y.size = x.size
        x.size = x.left.size + x.right.size + 1


    def insert(self, inserted_node):
        y = self.nil
        x = self.root
        while x != self.nil:
            y = x
            x.size += 1
            if inserted_node.key < x.key:
                x = x.left
            else:
                x = x.right

        inserted_node.parent = y

        if y == self.nil:
            self.root = inserted_node
        elif inserted_node.key < y.key:
            y.left = inserted_node
        else:
            y.right = inserted_node
        
        inserted_node.size  = 1
        inserted_node.left  = self.nil
        inserted_node.right = self.nil
        inserted_node.color = "red"
        self.insert_fixup(inserted_node)


    def delete(self, z):
        node = self.root
        while node != z:
            node.size -= 1
            if z.key < node.key:
                node = node.left
            else:
                node = node.right
        y = z
        y_original_color = y.color
        if z.left == self.nil:
            x = z.right
            self.transplant(z, z.right)
        elif z.right == self.nil:
            x = z.left
            self.transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            y_original_color = y.color
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self.transplant(y, y.right)
                y.right = z.right
                y.right.parent = y
            self.transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color

        y.size = y.left.size + y.right.size + 1
        if y_original_color == "black":
            self.delete_fixup(x)


    def minimum(self, x):
        while x.left != self.nil:
            x.size -= 1
            x = x.left
        return x


    def select(self, k):
        if "size" not in self.root.__dict__:
            raise IOError("construct_size() should be called before selece(k).")
        x = self.root
        while x != self.nil:
            lq = x.left.size + 1
            if lq == k:
                return x.key
            elif lq > k:
                x = x.left
            else:
                x = x.right
                k = k - lq


    def generate_node(self, node):
        text = 'key '+str(node.key)+'\n'+'size '+str(node.size)
        return pydot.Node(text, style="filled",fontcolor='ivory', fillcolor=node.color)


    def get_order(self, x):
        return self.search(x).left.size + 1




""""""""""""""" Interval RBTree """""""""""""""


class inttree(brtree):
    """docstring for os_tree"""
    def __init__(self):
        self.root = self.nil
        self.nil.low  = -1
        self.nil.high = -1
        self.nil.max  = -1
        

    def left_rotate(self, x):
        if x == self.nil or x.right == self.nil:
            return
        y = x.right

        x.right = y.left
        if y.left != self.nil:
            y.left.parent = x

        y.parent = x.parent
        if x.parent == self.nil:
            self.root = y
        elif x == x.parent.left:
            x.parent.left = y
        else:
            x.parent.right = y

        y.left = x
        x.parent = y

        y.max = x.max
        x.max = max([x.left.max, x.right.max, x.high])


    def right_rotate(self, x):
        if x == self.nil or x.left == self.nil:
            return
        y = x.left

        x.left = y.right
        if y.right != self.nil:
            y.right.parent = x

        y.parent = x.parent
        if x.parent == self.nil:
            self.root = y
        elif x.parent.left == x:
            x.parent.left = y
        else:
            x.parent.right = y

        y.right = x
        x.parent = y

        y.max = x.max
        x.max = max([x.left.max, x.right.max, x.high])


    def insert(self, inserted_node, low, high):
        inserted_node.key = low
        y = self.nil
        x = self.root
        while x != self.nil:
            y = x
            x.max = max([x.max, high])
            if inserted_node.key < x.key:
                x = x.left
            else:
                x = x.right

        inserted_node.parent = y

        if y == self.nil:
            self.root = inserted_node
        elif inserted_node.key < y.key:
            y.left = inserted_node
        else:
            y.right = inserted_node
        
        inserted_node.low   = low
        inserted_node.high  = high
        inserted_node.max   = high
        inserted_node.left  = self.nil
        inserted_node.right = self.nil
        inserted_node.color = "red"
        self.insert_fixup(inserted_node)


    def adjust_max(self, node, z):
        if node.key == z.key:
            return
        elif z.key < node.key:
            self.adjust_max(node.left, z)
            if node.left == z:
                node.max = max([z.left.max, z.right.max, node.high, node.right.max])
            else:
                node.max = max([node.left.max, node.right.max, node.high])
        else:
            self.adjust_max(node.right, z)
            if node.right == z:
                node.max = max([z.left.max, z.right.max, node.high, node.left.max])
            else:
                node.max = max([node.left.max, node.right.max, node.high])


    def delete(self, z):
        self.adjust_max(self.root, z)
        y = z
        y_original_color = y.color
        if z.left == self.nil:
            x = z.right
            self.transplant(z, z.right)
        elif z.right == self.nil:
            x = z.left
            self.transplant(z, z.left)
        else:
            y = self.minimum(z.right)
            y_original_color = y.color
            x = y.right
            if y.parent == z:
                x.parent = y
            else:
                self.transplant(y, y.right)
                y.right = z.right
                y.right.parent = y
            self.transplant(z, y)
            y.left = z.left
            y.left.parent = y
            y.color = z.color

        y.max = max([y.left.max, y.right.max, y.high])
        if y_original_color == "black":
            self.delete_fixup(x)


    def search_int(self, low, high):
        return self._search_int(self.root, low, high)


    def search_int_unique(self, low, high):
        x = self.root
        while x != self.nil and (x.low > high or x.high < low):
            if x.left != self.nil and x.left.max >= low:
                x = x.left
            else:
                x = x.right
        if x != self.nil:
            return [x.low, x.high]


    def _search_int(self, x, low, high):
        if x == self.nil:
            return []
        if x.max < low:
            return []
        elif x.low > high or x.high < low:
            return self._search_int(x.left, low, high) + self._search_int(x.right, low, high)
        else:
            return [[x.low, x.high]] + self._search_int(x.left, low, high) + self._search_int(x.right, low, high)


    def minimum(self, x):
        if x.left != self.nil:
            y = self.minimum(x.left)
            x.max = max([x.left.max, x.right.max, x.high])
            return y
        else:
            x.max = max([x.high, x.right.max])
            return x

    def generate_node(self, node):
        text = 'key ' + str(node.key) + ', max ' + str(node.max) + '\n' \
                + 'int [' + str(node.low) + ', ' + str(node.high) + ']\n'
        return pydot.Node(text, style="filled",fontcolor='ivory', fillcolor=node.color)
